///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

	/***********************************************************
	 *  Shared scene constants
	 *
	 *  Colors and rotations reused by several 3D objects are
	 *  named here so each object declaration stays short and
	 *  the values only exist in one place.
	 ***********************************************************/

	// shared colors
	const glm::vec4 COLOR_FLOOR(0.33f, 0.32f, 0.31f, 1.0f);
	const glm::vec4 COLOR_WALL_BACK(0.74f, 0.68f, 0.58f, 1.0f);
	const glm::vec4 COLOR_WALL_SIDE(0.66f, 0.60f, 0.51f, 1.0f);
	const glm::vec4 COLOR_DESK(0.10f, 0.09f, 0.09f, 1.0f);
	const glm::vec4 COLOR_CUBBY(0.23f, 0.16f, 0.11f, 1.0f);
	const glm::vec4 COLOR_MAT(0.19f, 0.20f, 0.24f, 1.0f);
	const glm::vec4 COLOR_BLACK(0.05f, 0.05f, 0.06f, 1.0f);
	const glm::vec4 COLOR_KEYCAP(0.20f, 0.20f, 0.23f, 1.0f);
	const glm::vec4 COLOR_SCREEN(0.16f, 0.22f, 0.34f, 1.0f);
	const glm::vec4 COLOR_SCREEN_SIDE(0.20f, 0.17f, 0.32f, 1.0f);
	const glm::vec4 COLOR_TV_SCREEN(0.30f, 0.42f, 0.55f, 1.0f);
	const glm::vec4 COLOR_TRACKBALL(0.45f, 0.08f, 0.10f, 1.0f);
	const glm::vec4 COLOR_METAL(0.35f, 0.35f, 0.38f, 1.0f);
	const glm::vec4 COLOR_DARK_GRAY(0.18f, 0.18f, 0.20f, 1.0f);
	const glm::vec4 COLOR_MIC(0.14f, 0.14f, 0.16f, 1.0f);
	const glm::vec4 COLOR_DRIVER(0.30f, 0.30f, 0.33f, 1.0f);

	// shared rotations - most objects either have no rotation
	// or share the 45 degree yaw of the desk's diagonal corner
	const glm::vec3 ROTATION_NONE(0.0f, 0.0f, 0.0f);
	const glm::vec3 ROTATION_DESK_DIAGONAL(0.0f, 45.0f, 0.0f);

	// texture tag names - constants keep the tags consistent
	// between LoadSceneTextures() and every scene object that
	// uses them, so a typo becomes a compile error instead of
	// an object silently losing its texture
	const char* TEXTURE_FLOOR = "floor";
	const char* TEXTURE_WOOD = "wood";
	const char* TEXTURE_WALL = "wall";
	const char* TEXTURE_PLASTIC = "plastic";
	const char* TEXTURE_CARBON = "carbon";
	const char* TEXTURE_SCREEN = "screen";
	const char* TEXTURE_SCREEN_SIDE = "screen_side";
	const char* TEXTURE_TV = "tv";
	const char* TEXTURE_GRILLE = "grille";
	const char* TEXTURE_BALL = "ball";

	// material tag names - each tag is defined in
	// DefineObjectMaterials() and passed to the scene objects
	// that need a finish other than the default matte
	const char* MATERIAL_MATTE = "matte";
	const char* MATERIAL_GLOSSY = "glossy";
	const char* MATERIAL_SCREEN = "screen_glow";
	const char* MATERIAL_LED = "led_glow";

	/***********************************************************
	 *  KeyLedColor()
	 *
	 *  Converts a 0..1 position across the keyboard width into
	 *  a dimmed rainbow color for the per-key RGB backlight
	 *  plates. Three phase-shifted sine waves sweep the color
	 *  red -> green -> blue -> red like real RGB key lighting.
	 ***********************************************************/
	glm::vec3 KeyLedColor(float t)
	{
		const float TWO_PI = 6.2831853f;
		const float DIM = 0.65f;	// keeps the glow subtle
		return glm::vec3(
			DIM * (0.5f + 0.5f * glm::sin(TWO_PI * t)),
			DIM * (0.5f + 0.5f * glm::sin(TWO_PI * t - 2.0944f)),
			DIM * (0.5f + 0.5f * glm::sin(TWO_PI * t - 4.1888f)));
	}
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	// no textures are loaded until PrepareScene runs - the
	// counter must start at zero or the texture array index
	// is garbage
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// free the loaded textures from GPU memory and clear the
	// defined materials list
	DestroyGLTextures();
	m_objectMaterials.clear();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// free the GPU memory held by each loaded texture
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  RenderObject()
 *
 *  Renders one SceneObject: sends its scale -> rotate ->
 *  translate transform and its color or texture to the
 *  shader, then draws its basic mesh. Every 3D object in the
 *  scene goes through this single method so the render
 *  functions stay short and easy to read.
 ***********************************************************/
void SceneManager::RenderObject(const SceneObject& object)
{
	const glm::vec3& rotation = object.Rotation();
	const glm::vec4& color = object.Color();

	SetTransformations(
		object.Scale(),
		rotation.x,
		rotation.y,
		rotation.z,
		object.Position());

	// send the object's material to the shader so the light
	// sources know how its surface reacts (ambient, diffuse,
	// specular, and shininess)
	SetShaderMaterial(object.MaterialTag());

	// textured objects draw with their image at the given UV
	// tiling scale; the texture slot is verified first so an
	// object whose image failed to load - or one with no
	// texture tag at all - falls back to its solid color
	if (object.HasTexture() && FindTextureSlot(object.TextureTag()) != -1)
	{
		SetShaderTexture(object.TextureTag());
		SetTextureUVScale(object.UVScale().x, object.UVScale().y);
	}
	else
	{
		SetShaderColor(color.r, color.g, color.b, color.a);
	}

	object.DrawMesh(m_basicMeshes);
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads every image file the scene needs into OpenGL
 *  textures and binds them to texture slots. Tags are the
 *  names scene objects use to pick their texture. All
 *  images are square seamless textures of at least 1024px
 *  so they can tile without visible seams - the wood floor,
 *  plaster, plastic, and carbon fiber images are CC0 from
 *  ambientcg.com; the screen wallpapers, speaker grille, and
 *  trackball images were generated for this project.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// tracks whether every texture loads so a warning can be
	// printed if any image file is missing or unreadable
	bool bAllLoaded = true;

	// gray ceramic tiles for the floor - tiled across the room
	bAllLoaded &= CreateGLTexture(
		"textures/floortile.jpg",
		TEXTURE_FLOOR);

	// seamless wood planks for the cubby shelf units
	bAllLoaded &= CreateGLTexture(
		"textures/woodfloor.jpg",
		TEXTURE_WOOD);

	// light painted plaster for the walls and cubby shelf
	bAllLoaded &= CreateGLTexture(
		"textures/plaster.jpg",
		TEXTURE_WALL);

	// dark rubber grain for the desk, monitor bezels, keyboard,
	// and other electronics housings
	bAllLoaded &= CreateGLTexture(
		"textures/plastic.jpg",
		TEXTURE_PLASTIC);

	// dark woven carbon-fiber fabric for the desk mat
	bAllLoaded &= CreateGLTexture(
		"textures/carbonfiber.jpg",
		TEXTURE_CARBON);

	// generated desktop wallpapers for the monitor and TV screens
	bAllLoaded &= CreateGLTexture(
		"textures/wallpaper_center.jpg",
		TEXTURE_SCREEN);
	bAllLoaded &= CreateGLTexture(
		"textures/wallpaper_side.jpg",
		TEXTURE_SCREEN_SIDE);
	bAllLoaded &= CreateGLTexture(
		"textures/wallpaper_tv.jpg",
		TEXTURE_TV);

	// perforated metal grille for the mic head and soundbar front
	bAllLoaded &= CreateGLTexture(
		"textures/grille.jpg",
		TEXTURE_GRILLE);

	// mottled red for the glossy trackball sphere
	bAllLoaded &= CreateGLTexture(
		"textures/ball.jpg",
		TEXTURE_BALL);

	// on failure: RenderObject() checks that a texture actually
	// loaded before using it and falls back to the object's solid
	// color, so a missing image never renders a blank object
	if (!bAllLoaded)
	{
		std::cout << "WARNING: one or more textures failed to load - affected objects will use their solid color" << std::endl;
	}

	// bind all loaded textures to OpenGL texture slots
	BindGLTextures();
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines the material finishes the scene objects use. The
 *  properties fed to the Phong lighting model are:
 *    ambientColor    - color the surface reflects under
 *                      indirect light (shadowed areas)
 *    ambientStrength - how strongly the surface reacts to
 *                      ambient light; values near 1 make a
 *                      surface look self-illuminated
 *    diffuseColor    - main color reflected under direct light
 *    specularColor   - color of the light's shiny highlight
 *    shininess       - highlight tightness (higher = sharper)
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// matte - default finish for most objects: walls, desk,
	// cubbies, keyboard, and plastic housings reflect light
	// softly with no real highlight
	OBJECT_MATERIAL matteMaterial;
	matteMaterial.ambientColor = glm::vec3(0.18f, 0.18f, 0.18f);
	matteMaterial.ambientStrength = 0.5f;
	matteMaterial.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);
	matteMaterial.specularColor = glm::vec3(0.06f, 0.06f, 0.06f);
	matteMaterial.shininess = 4.0f;
	matteMaterial.tag = MATERIAL_MATTE;
	m_objectMaterials.push_back(matteMaterial);

	// glossy - reflective finish for the ceramic floor tile and
	// the trackball so the light sources reflect off their
	// surfaces with bright, tight highlights
	OBJECT_MATERIAL glossyMaterial;
	glossyMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	glossyMaterial.ambientStrength = 0.5f;
	glossyMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	glossyMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glossyMaterial.shininess = 32.0f;
	glossyMaterial.tag = MATERIAL_GLOSSY;
	m_objectMaterials.push_back(glossyMaterial);

	// screen - monitor and TV faces; the near-full ambient
	// strength makes them keep most of their brightness even
	// where the lights do not reach, so the displays read as
	// powered-on emissive surfaces
	OBJECT_MATERIAL screenMaterial;
	screenMaterial.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screenMaterial.ambientStrength = 0.85f;
	screenMaterial.diffuseColor = glm::vec3(0.05f, 0.05f, 0.05f);
	screenMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	screenMaterial.shininess = 16.0f;
	screenMaterial.tag = MATERIAL_SCREEN;
	m_objectMaterials.push_back(screenMaterial);

	// led - the RGB backlight plates under the keycaps; high
	// ambient makes the dimmed colors look lit even though they
	// sit in the shadow of the caps
	OBJECT_MATERIAL ledMaterial;
	ledMaterial.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ledMaterial.ambientStrength = 0.8f;
	ledMaterial.diffuseColor = glm::vec3(0.1f, 0.1f, 0.1f);
	ledMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	ledMaterial.shininess = 1.0f;
	ledMaterial.tag = MATERIAL_LED;
	m_objectMaterials.push_back(ledMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Configures the light sources for the scene. The shader
 *  supports up to four light sources; each has:
 *    position          - XYZ location of the light
 *    ambientColor      - flat light added everywhere, also
 *                        where the light's color tint shows
 *    diffuseColor      - color of the direct illumination
 *    specularColor     - color of the produced highlights
 *    focalStrength     - sharpness of the specular highlight
 *    specularIntensity - brightness of the specular highlight
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the
	// default OpenGL lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// light 0 - main ceiling light: a soft white point light high
	// in the middle of the room so every object is clearly lit
	// and nothing sits in complete shadow
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 9.5f, 1.5f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.08f, 0.08f, 0.07f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.7f, 0.7f, 0.65f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.5f);

	// light 1 - warm fill light low in front of the desk, like a
	// desk lamp; its warm ambient tint keeps the front faces of
	// the desk items lit and adds a cozy cast to the scene
	m_pShaderManager->setVec3Value("lightSources[1].position", -1.0f, 6.5f, 5.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.06f, 0.04f, 0.02f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.6f, 0.45f, 0.25f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.5f, 0.35f, 0.15f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.35f);

	// light 2 - cool blue glow just in front of the monitor
	// array, like light spilling off the displays; the faint
	// blue ambient adds a cool tone to the desk area
	m_pShaderManager->setVec3Value("lightSources[2].position", -8.0f, 5.5f, -3.5f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.02f, 0.03f, 0.06f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.2f, 0.3f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.1f, 0.15f, 0.3f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.2f);

	// light 3 - dim neutral fill behind the camera so the back
	// edges of the room never render completely black
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 6.0f, 12.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.035f, 0.035f, 0.035f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.15f, 0.15f, 0.15f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.05f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene - the scene is built from the
	// plane, box, cylinder, tapered cylinder, sphere, and
	// torus basic shapes

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTorusMesh();

	// load the texture images applied to the scene objects
	LoadSceneTextures();
	// define the material finishes the scene objects use
	DefineObjectMaterials();
	// add and configure the light sources for the scene
	SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes. The scene
 *  recreates the corner desk setup from the 2D reference
 *  image: two walls meeting in a corner, a wall-mounted
 *  (floating) desk with a cubby shelf unit tucked under the
 *  right end, a desk mat, keyboard, and mouse on top, and a
 *  triple monitor array wrapping the corner.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// draw the floor and the two walls that form the corner
	RenderRoomSurfaces();

	// draw the floating desk, cubby shelf, and desktop items
	RenderDesk();

	// draw the three monitors standing on the desk and the
	// wall-mounted TV
	RenderMonitors();

	// draw the trackball mouse, boom microphone, and soundbar
	RenderAccessories();
}

/***********************************************************
 *  RenderRoomSurfaces()
 *
 *  This method draws the floor and the two walls that form
 *  the corner of the room from the 2D reference image. All
 *  three surfaces are built from the basic plane mesh.
 ***********************************************************/
void SceneManager::RenderRoomSurfaces()
{
	/******************************************************************/
	/*** FLOOR PLANE                                                ***/
	/*** The plane mesh lies flat in the XZ plane by default and    ***/
	/*** spans 2x2 units, so scaling sets half the floor's extents  ***/
	/******************************************************************/
	// half extents that put the
	// floor edges at the walls: x[-10,12] and z[-7,10]
	// none needed, the plane
	// already lies flat in the XZ plane by default
	// shifted so the floor
	// edges meet the back wall (z=-7) and the left wall (x=-10)
	// gray ceramic tiles, tiled 3x2 across the room; the glossy
	// material makes the light sources reflect off the floor
	RenderObject(SceneObject(SceneObject::PLANE,
		glm::vec3(11.0f, 1.0f, 8.5f), ROTATION_NONE,
		glm::vec3(1.0f, 0.0f, 1.5f), COLOR_FLOOR, TEXTURE_FLOOR, glm::vec2(3.0f, 2.0f),
		MATERIAL_GLOSSY));
	/****************************************************************/

	/******************************************************************/
	/*** BACK WALL PLANE                                            ***/
	/*** This is the front-facing wall on the right side of the     ***/
	/*** reference image (the wall the desk is mounted on)          ***/
	/******************************************************************/
	// half extents matching the
	// floor: x half-extent 11 and a half height of 5
	// 90 degrees about X tips
	// the flat plane upright into a vertical wall (its scaled Z
	// extent becomes vertical height) facing the camera
	// pushed back to z=-7 and
	// lifted so the wall bottom meets the floor at y=0
	// light painted plaster, tiled 4x2 across the wall
	RenderObject(SceneObject(SceneObject::PLANE,
		glm::vec3(11.0f, 1.0f, 5.0f), glm::vec3(90.0f, 0.0f, 0.0f),
		glm::vec3(1.0f, 5.0f, -7.0f), COLOR_WALL_BACK, TEXTURE_WALL, glm::vec2(4.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT WALL PLANE                                            ***/
	/*** This is the poster wall on the left side of the reference  ***/
	/*** image; it meets the back wall at the corner behind the     ***/
	/*** left end of the desk                                       ***/
	/******************************************************************/
	// after the Z rotation below,
	// the plane's X extent becomes the vertical height (half 5)
	// and the Z extent becomes the wall length (half 8.5)
	// -90 degrees about Z turns
	// the flat plane's normal from +Y to +X so it stands upright
	// along the left side of the room facing into the room
	// at the floor's left edge
	// x=-10, centered vertically, meeting the back wall at the
	// corner (x=-10, z=-7)
	// same light plaster as the back wall, tiled 4x2
	// than the back wall to distinguish the two surfaces
	RenderObject(SceneObject(SceneObject::PLANE,
		glm::vec3(5.0f, 1.0f, 8.5f), glm::vec3(0.0f, 0.0f, -90.0f),
		glm::vec3(-10.0f, 5.0f, 1.5f), COLOR_WALL_SIDE, TEXTURE_WALL, glm::vec2(4.0f, 2.0f)));
	/****************************************************************/
}

/***********************************************************
 *  RenderDesk()
 *
 *  This method draws the complex desk object from the 2D
 *  reference image. The desk is a floating (wall-mounted, no
 *  legs) L-shaped black corner desktop with a small open cubby
 *  compartment hanging beneath its right end. A desk mat,
 *  keyboard, and mouse sit on top. Everything is built from
 *  box meshes.
 ***********************************************************/
void SceneManager::RenderDesk()
{
	/******************************************************************/
	/*** DESKTOP SLAB - BACK WALL                                   ***/
	/*** The box mesh is a unit cube centered at its position, so   ***/
	/*** scaling sets the full width, thickness, and depth          ***/
	/******************************************************************/
	// long and thin: 14 wide,
	// 0.3 thick, and 2.8 deep like the desktop in the image
	// none needed, the slab
	// is already oriented parallel to the floor
	// mounted on the back wall
	// at desk height (y=4.15 puts the surface at y=4.3), with the
	// back edge flush against the wall (z=-7) and the left end
	// flush against the left wall (x=-10); no legs since the desk
	// is floating
	// near black like the
	// desktop in the reference image
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(14.0f, 0.3f, 2.8f), ROTATION_NONE,
		glm::vec3(-3.0f, 4.15f, -5.6f), COLOR_DESK, TEXTURE_PLASTIC, glm::vec2(4.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** DESKTOP SLAB - LEFT WALL                                   ***/
	/*** A second slab of the same size as the back wall desktop,   ***/
	/*** rotated 90 degrees so it runs along the left wall and      ***/
	/*** turns the straight desk into an L-shaped corner desk       ***/
	/******************************************************************/
	// same size as the back wall
	// desktop slab: 14 long, 0.3 thick, and 2.8 deep
	// 90 degrees about Y turns
	// the slab so its length runs along the left wall instead of
	// along the back wall
	// flush against the left
	// wall (x=-10), starting at the wall corner (z=-7) and running
	// 14 units along the wall so this wing extends out the same
	// distance as the back wall wing; lowered 0.01 so the small
	// section that overlaps the back wall slab in the corner sits
	// just under it and the two coplanar surfaces do not flicker
	// same near black as
	// the back wall desktop so the two slabs read as one desk
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(14.0f, 0.3f, 2.8f), glm::vec3(0.0f, 90.0f, 0.0f),
		glm::vec3(-8.6f, 4.14f, 0.0f), COLOR_DESK, TEXTURE_PLASTIC, glm::vec2(4.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CORNER WEDGE                                               ***/
	/*** A box rotated 45 degrees about Y and centered on the inner ***/
	/*** corner where the front edges of the two desktop slabs meet ***/
	/*** (x=-7.2, z=-4.2). The quarter of the diamond that faces    ***/
	/*** into the room forms a right triangle, and its hypotenuse   ***/
	/*** becomes the diagonal front edge of the desk at the corner, ***/
	/*** giving the L-shape an alcove / corner desk look. The other ***/
	/*** three quarters of the diamond sit inside the desktop slabs ***/
	/******************************************************************/
	// same 0.3 thickness as the
	// desktop; the 3.96 x/z size (2.8 * sqrt(2)) makes the rotated
	// corners of the box land exactly one desktop depth (2.8 units)
	// out along each front edge
	// 45 degrees about Y turns
	// the square into a diamond so the room-facing quarter is a
	// right triangle with its right angle at the slabs' inner corner
	// centered on the inner
	// corner where the slab front edges meet; lowered 0.02 so the
	// hidden quarters sit just under the slab tops and do not
	// flicker where the surfaces overlap
	// same near black as
	// the desktop slabs so the corner piece blends in
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(3.96f, 0.3f, 3.96f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-7.2f, 4.12f, -4.2f), COLOR_DESK, TEXTURE_PLASTIC, glm::vec2(2.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CUBBY - LEFT SIDE PANEL                                    ***/
	/*** The cubby is a small open-front shelf compartment hanging  ***/
	/*** beneath the right end of the desktop; it does not reach    ***/
	/*** the floor                                                  ***/
	/******************************************************************/
	// thin vertical panel as tall
	// as the hanging compartment (1.5) and as deep as the cubby
	// left side of the cubby,
	// spanning y=2.5 to y=4.0 so the top tucks just under the
	// desktop and the bottom floats above the floor
	// wood planks to
	// distinguish the cubby from the desktop
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.12f, 1.5f, 2.4f), ROTATION_NONE,
		glm::vec3(2.26f, 3.25f, -5.6f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CUBBY - RIGHT SIDE PANEL                                   ***/
	/******************************************************************/
	// same as the left panel
	// right side of the cubby,
	// flush with the right end of the desktop at x=4
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.12f, 1.5f, 2.4f), ROTATION_NONE,
		glm::vec3(3.94f, 3.25f, -5.6f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CUBBY - BACK PANEL                                         ***/
	/******************************************************************/
	// spans the interior width
	// between the two side panels and matches their height
	// centered on the cubby
	// and pushed back against the wall
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(1.56f, 1.5f, 0.12f), ROTATION_NONE,
		glm::vec3(3.1f, 3.25f, -6.74f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CUBBY - BOTTOM SHELF                                       ***/
	/******************************************************************/
	// thin horizontal panel
	// spanning the cubby interior
	// the floor of the hanging
	// compartment, flush with the bottoms of the side panels at
	// y=2.5 and floating well above the floor
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(1.56f, 0.12f, 2.26f), ROTATION_NONE,
		glm::vec3(3.1f, 2.56f, -5.54f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CUBBY - TOP PANEL                                          ***/
	/******************************************************************/
	// same as the bottom shelf
	// flush with the underside
	// of the desktop at y=4.0
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(1.56f, 0.12f, 2.26f), ROTATION_NONE,
		glm::vec3(3.1f, 3.94f, -5.54f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT WING CUBBY - BACK SIDE PANEL                          ***/
	/*** A matching open-front shelf compartment hanging beneath  ***/
	/*** the far end of the left wall desktop wing; it is the same  ***/
	/*** size as the back wall cubby but turned to face the room    ***/
	/******************************************************************/
	// thin vertical panel as tall
	// as the hanging compartment (1.5) and as deep as the cubby;
	// the panel is thin in Z this time since the wing runs along Z
	// back side of the cubby
	// (toward the corner), spanning y=2.5 to y=4.0 just like the
	// matching cubby so the bottom floats above the floor
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(2.4f, 1.5f, 0.12f), ROTATION_NONE,
		glm::vec3(-8.6f, 3.25f, 5.26f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT WING CUBBY - FRONT SIDE PANEL                         ***/
	/******************************************************************/
	// same as the back panel
	// front side of the cubby,
	// flush with the front end of the left wing desktop at z=7
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(2.4f, 1.5f, 0.12f), ROTATION_NONE,
		glm::vec3(-8.6f, 3.25f, 6.94f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT WING CUBBY - BACK PANEL                               ***/
	/******************************************************************/
	// thin in X against the left
	// wall, spanning the interior width between the side panels
	// centered on the cubby
	// and pushed back against the left wall
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.12f, 1.5f, 1.56f), ROTATION_NONE,
		glm::vec3(-9.74f, 3.25f, 6.1f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT WING CUBBY - BOTTOM SHELF                             ***/
	/******************************************************************/
	// thin horizontal panel
	// spanning the cubby interior
	// the floor of the hanging
	// compartment, flush with the bottoms of the side panels at
	// y=2.5 and floating well above the floor
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(2.26f, 0.12f, 1.56f), ROTATION_NONE,
		glm::vec3(-8.54f, 2.56f, 6.1f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT WING CUBBY - TOP PANEL                                ***/
	/******************************************************************/
	// same as the bottom shelf
	// flush with the underside
	// of the left wing desktop at y=4.0
	// wood planks
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(2.26f, 0.12f, 1.56f), ROTATION_NONE,
		glm::vec3(-8.54f, 3.94f, 6.1f), COLOR_CUBBY, TEXTURE_WOOD, glm::vec2(2.0f, 2.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** DESK MAT                                                   ***/
	/*** The large dark mat on the desk surface that the keyboard   ***/
	/*** and mouse sit on in the reference image                    ***/
	/******************************************************************/
	// a very thin wide slab
	// 45 degrees about Y turns
	// the mat so its long edge runs parallel to the diagonal front
	// edge of the desk at the corner
	// resting on the desktop
	// surface (y=4.3), centered on the diagonal corner section of
	// the desk where a user would sit at the corner
	// dark carbon fiber weave,
	// slightly lighter than the desktop so it stands out
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(5.5f, 0.06f, 1.9f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-6.8f, 4.33f, -3.8f), COLOR_MAT, TEXTURE_CARBON, glm::vec2(2.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** KEYBOARD - BASE                                            ***/
	/*** The deck that all 103 keycaps sit on                       ***/
	/******************************************************************/
	// wide, thin, and shallow
	// like a full-size keyboard with a numpad
	// 45 degrees about Y to
	// match the rotated desk mat at the diagonal corner
	// on the mat near its
	// front edge, shifted left along the diagonal so the right
	// end clears the trackball mouse
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(3.0f, 0.10f, 1.0f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-6.88f, 4.41f, -3.32f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(2.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** KEYBOARD - KEYCAPS                                         ***/
	/*** All 103 keys are small boxes drawn in loops: the function  ***/
	/*** row, five typing rows, the navigation cluster with arrow   ***/
	/*** keys, and the 4x4 numpad. Each key position is computed in ***/
	/*** the keyboard's local space, rotated by its 45 degree yaw,  ***/
	/*** then translated so the cap sits on the base              ***/
	/******************************************************************/
	// keyboard center and yaw shared with the base so the caps
	// and the deck always stay aligned
	const float kbCenterX = -6.88f;
	const float kbCenterZ = -3.32f;
	const float kbYawRadians = glm::radians(45.0f);

	// keycap size and spacing measured in the keyboard's local
	// space, before the 45 degree rotation; the caps are a touch
	// smaller than the pitch so the deck shows through between
	// them like the gaps in the reference keyboard
	const float keyPitch = 0.132f;
	const glm::vec3 keyScale(0.095f, 0.07f, 0.095f);
	const float keyHeight = 4.495f;

	// each row lists the local X of its first key, its local Z,
	// and how many keys it holds; the gaps between entries mirror
	// a real 103-key layout - function key groups, the navigation
	// cluster, and the numpad all sit apart from the typing keys
	struct KeyRow
	{
		float startX;
		float z;
		int keyCount;
	};
	const KeyRow keyRows[] =
	{
		{ -1.24f, -0.440f,  1 },	// Esc
		{ -1.10f, -0.440f,  4 },	// F1 - F4
		{ -0.60f, -0.440f,  4 },	// F5 - F8
		{ -0.10f, -0.440f,  4 },	// F9 - F12
		{  0.62f, -0.440f,  3 },	// Print Screen, Scroll Lock, Pause
		{ -1.24f, -0.265f, 14 },	// number row
		{ -1.24f, -0.110f, 14 },	// QWERTY row
		{ -1.24f,  0.045f, 13 },	// home row
		{ -1.24f,  0.200f, 12 },	// bottom letter row
		{ -1.24f,  0.355f,  3 },	// Ctrl, Win, Alt left of spacebar
		{ -0.184f, 0.355f,  4 },	// Alt, Fn, Menu, Ctrl right of it
		{  0.62f, -0.265f,  3 },	// Insert, Home, Page Up
		{  0.62f, -0.110f,  3 },	// Delete, End, Page Down
		{  0.752f, 0.200f,  1 },	// up arrow
		{  0.62f,  0.355f,  3 },	// left, down, right arrows
		{  0.98f, -0.265f,  4 },	// numpad
		{  0.98f, -0.110f,  4 },
		{  0.98f,  0.045f,  4 },
		{  0.98f,  0.200f,  4 },
	};

	// draw every keycap
	for (const KeyRow& row : keyRows)
	{
		for (int key = 0; key < row.keyCount; ++key)
		{
			// local offset of this key on the keyboard deck
			float localX = row.startX + key * keyPitch;
			float localZ = row.z;

			// rotate the offset by the keyboard's 45 degree yaw,
			// then translate it to the keyboard's position
			glm::vec3 keyPosition(
				kbCenterX + localX * glm::cos(kbYawRadians) + localZ * glm::sin(kbYawRadians),
				keyHeight,
				kbCenterZ - localX * glm::sin(kbYawRadians) + localZ * glm::cos(kbYawRadians));

			// per-key RGB backlight plate: a thin box a touch
			// wider than the keycap tucked just under it, so a
			// sliver of dimmed color glows through the gap
			// around the cap; the column position picks the
			// color so the glow sweeps a rainbow across the
			// keyboard like real per-key RGB backlighting
			float ledT = glm::clamp((localX + 1.24f) / 2.6f, 0.0f, 1.0f);
			RenderObject(SceneObject(SceneObject::BOX,
				glm::vec3(0.12f, 0.03f, 0.12f), ROTATION_DESK_DIAGONAL,
				glm::vec3(keyPosition.x, 4.457f, keyPosition.z),
				glm::vec4(KeyLedColor(ledT), 1.0f),
				"", glm::vec2(1.0f), MATERIAL_LED));

			RenderObject(SceneObject(SceneObject::BOX, keyScale,
				ROTATION_DESK_DIAGONAL, keyPosition, COLOR_KEYCAP, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
		}
	}
	/****************************************************************/

	/******************************************************************/
	/*** KEYBOARD - SPACEBAR                                        ***/
	/*** One extra-wide keycap spanning about five normal key slots ***/
	/*** in the middle of the bottom row; counts as key 103         ***/
	/******************************************************************/
	// same height and depth as the
	// other keycaps but about five times as wide
	// same 45 degree yaw as the
	// rest of the keyboard
	// local (-0.58, 0.355) on
	// the deck, rotated and translated like the caps above
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.60f, 0.07f, 0.095f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-7.039f, 4.495f, -2.659f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));

	// matching RGB glow plate under the spacebar, colored from
	// the middle of the keyboard's rainbow sweep
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.62f, 0.03f, 0.12f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-7.039f, 4.457f, -2.659f), glm::vec4(KeyLedColor(0.45f), 1.0f),
		"", glm::vec2(1.0f), MATERIAL_LED));
	/****************************************************************/

	// the trackball mouse, boom microphone, and soundbar on the
	// desk are drawn by RenderAccessories()
}

/***********************************************************
 *  RenderMonitors()
 *
 *  This method draws the triple monitor array from the 2D
 *  reference image. A landscape monitor sits in the corner
 *  angled 45 degrees toward the user, flanked by two portrait
 *  monitors angled inward so all three screens face the
 *  keyboard position, matching the wrap-around setup in the
 *  image. Each monitor is built from four box meshes: a base
 *  plate, a stand neck, the bezel, and the screen face.
 ***********************************************************/
void SceneManager::RenderMonitors()
{
	/******************************************************************/
	/*** CENTER MONITOR - STAND BASE                                ***/
	/*** The center landscape monitor stands in the corner of the   ***/
	/*** desk, rotated 45 degrees so it faces the user diagonally   ***/
	/******************************************************************/
	// small flat plate the stand
	// sits on
	// 45 degrees about Y to
	// match the monitor facing the user at the desk's diagonal
	// corner
	// resting on the desktop
	// (y=4.3) in the corner of the desk
	// black like the monitor
	// stands in the reference image
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.7f, 0.08f, 0.5f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-8.5f, 4.34f, -6.0f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CENTER MONITOR - STAND NECK                                ***/
	/******************************************************************/
	// thin vertical post lifting
	// the screen above the desk
	// spanning from the base
	// plate up to the bottom of the screen at y=5.0
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.18f, 0.62f, 0.18f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-8.5f, 4.69f, -6.0f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CENTER MONITOR - BEZEL                                     ***/
	/******************************************************************/
	// wide and short like the
	// landscape center monitor in the reference image
	// 45 degrees about Y so the
	// screen faces the user sitting at the diagonal corner
	// centered so its bottom
	// edge rests at y=5.0 on top of the stand neck
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(2.6f, 1.5f, 0.15f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-8.5f, 5.75f, -6.0f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** CENTER MONITOR - SCREEN FACE                               ***/
	/*** A slightly smaller, slightly thicker box sharing the       ***/
	/*** bezel's center so it protrudes just past the front face    ***/
	/*** and reads as the lit display                               ***/
	/******************************************************************/
	// a touch narrower and shorter
	// than the bezel, and a touch deeper so the face pokes out
	// same 45 degrees as the bezel
	// shares the bezel center
	// indigo desktop wallpaper image
	// indigo desktop wallpaper image; the screen material keeps
	// the face bright so it reads as a powered-on display
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(2.48f, 1.38f, 0.17f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-8.5f, 5.75f, -6.0f), COLOR_SCREEN, TEXTURE_SCREEN, glm::vec2(1.0f, 1.0f),
		MATERIAL_SCREEN));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT MONITOR - STAND BASE                                  ***/
	/*** The left portrait monitor stands on the left wall wing of  ***/
	/*** the desk, angled inward toward the user                    ***/
	/******************************************************************/
	// same flat plate as the center
	// 80 degrees about Y angles
	// the screen inward so it faces the user and its right bezel
	// edge meets the center monitor's left edge
	// on the left wing of the
	// desk, tucked against the center monitor so the bezels touch
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.7f, 0.08f, 0.5f), glm::vec3(0.0f, 80.0f, 0.0f),
		glm::vec3(-9.53f, 4.34f, -4.44f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT MONITOR - STAND NECK                                  ***/
	/******************************************************************/
	// same thin post as the center
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.18f, 0.62f, 0.18f), glm::vec3(0.0f, 80.0f, 0.0f),
		glm::vec3(-9.53f, 4.69f, -4.44f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT MONITOR - BEZEL                                       ***/
	/******************************************************************/
	// tall and narrow like the
	// portrait orientation side monitors in the reference image
	// 80 degrees about Y angles
	// the screen inward toward the user
	// bottom edge at y=5.0,
	// matching the center monitor's screen height
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(1.3f, 2.3f, 0.15f), glm::vec3(0.0f, 80.0f, 0.0f),
		glm::vec3(-9.53f, 6.15f, -4.44f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** LEFT MONITOR - SCREEN FACE                                 ***/
	/******************************************************************/
	// a touch narrower and shorter
	// than the bezel, and a touch deeper so the face pokes out
	// same as the bezel
	// shares the bezel center
	// purple galaxy wallpaper image
	// purple galaxy wallpaper image; screen material for a
	// powered-on look
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(1.18f, 2.18f, 0.17f), glm::vec3(0.0f, 80.0f, 0.0f),
		glm::vec3(-9.53f, 6.15f, -4.44f), COLOR_SCREEN_SIDE, TEXTURE_SCREEN_SIDE, glm::vec2(1.0f, 1.0f),
		MATERIAL_SCREEN));
	/****************************************************************/

	/******************************************************************/
	/*** RIGHT MONITOR - STAND BASE                                 ***/
	/*** The right portrait monitor stands on the back wall wing    ***/
	/*** of the desk, angled inward toward the user                 ***/
	/******************************************************************/
	// same flat plate as the others
	// -10 degrees about Y angles
	// the screen inward so its left bezel edge meets the center
	// monitor's right edge
	// on the back wall wing of
	// the desk, tucked against the center monitor so the bezels
	// touch
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.7f, 0.08f, 0.5f), glm::vec3(0.0f, -10.0f, 0.0f),
		glm::vec3(-6.94f, 4.34f, -6.79f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** RIGHT MONITOR - STAND NECK                                 ***/
	/******************************************************************/
	// same thin post as the others
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.18f, 0.62f, 0.18f), glm::vec3(0.0f, -10.0f, 0.0f),
		glm::vec3(-6.94f, 4.69f, -6.79f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** RIGHT MONITOR - BEZEL                                      ***/
	/******************************************************************/
	// tall and narrow portrait
	// like the left monitor
	// -10 degrees about Y angles
	// the screen inward toward the user
	// bottom edge at y=5.0,
	// matching the other monitors' screen height
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(1.3f, 2.3f, 0.15f), glm::vec3(0.0f, -10.0f, 0.0f),
		glm::vec3(-6.94f, 6.15f, -6.79f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** RIGHT MONITOR - SCREEN FACE                                ***/
	/******************************************************************/
	// a touch narrower and shorter
	// than the bezel, and a touch deeper so the face pokes out
	// same as the bezel
	// shares the bezel center
	// dark blue gray like the
	// powered-on display on the right screen in the image
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(1.18f, 2.18f, 0.17f), glm::vec3(0.0f, -10.0f, 0.0f),
		glm::vec3(-6.94f, 6.15f, -6.79f), COLOR_SCREEN, TEXTURE_SCREEN_SIDE, glm::vec2(1.0f, 1.0f),
		MATERIAL_SCREEN));
	/****************************************************************/

	/******************************************************************/
	/*** WALL-MOUNTED TV - WALL BRACKET                             ***/
	/*** The TV mounted on the back wall to the right of the        ***/
	/*** monitor array in the reference image, tilted slightly      ***/
	/*** downward toward the user                                   ***/
	/******************************************************************/
	// small mount plate behind
	// the screen, flush against the wall
	// same downward tilt as
	// the screen so the bracket meets its back flat
	// against the back wall
	// (z=-7) behind the screen center
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.5f, 0.5f, 0.18f), glm::vec3(8.0f, 0.0f, 0.0f),
		glm::vec3(-1.5f, 6.6f, -6.9f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** WALL-MOUNTED TV - BEZEL                                    ***/
	/******************************************************************/
	// wider than the desk monitors
	// like the TV in the reference image
	// 8 degrees about X tips
	// the screen's top edge back so it tilts down toward the user
	// mounted on the back wall
	// to the right of the monitor array, above the desk's right end
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(3.2f, 1.9f, 0.12f), glm::vec3(8.0f, 0.0f, 0.0f),
		glm::vec3(-1.5f, 6.6f, -6.78f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** WALL-MOUNTED TV - SCREEN FACE                              ***/
	/******************************************************************/
	// a touch narrower and shorter
	// than the bezel, and a touch deeper so the face pokes out
	// same tilt as the bezel
	// shares the bezel center
	// blue desktop wallpaper like the TV in the reference image
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(3.08f, 1.78f, 0.14f), glm::vec3(8.0f, 0.0f, 0.0f),
		glm::vec3(-1.5f, 6.6f, -6.78f), COLOR_TV_SCREEN, TEXTURE_TV, glm::vec2(1.0f, 1.0f),
		MATERIAL_SCREEN));
	/****************************************************************/
}

/***********************************************************
 *  RenderAccessories()
 *
 *  This method draws the remaining desktop items from the 2D
 *  reference image: the trackball mouse (four buttons, a
 *  central ball, and a scroll ring around the ball), the
 *  boom microphone on the right side of the desk, and the
 *  soundbar laying under the middle monitor.
 ***********************************************************/
void SceneManager::RenderAccessories()
{
	/******************************************************************/
	/*** TRACKBALL MOUSE - BODY                                     ***/
	/*** This mouse is a trackball: a wide flat body holding four   ***/
	/*** buttons, a ball in the middle used to move the cursor,     ***/
	/*** and a click wheel ring around the ball                     ***/
	/******************************************************************/
	// wide flat body
	// 45 degrees about Y to
	// match the rotated desk mat and keyboard at the corner
	// on the mat beside the
	// keyboard along the diagonal front edge of the desk
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.85f, 0.16f, 0.95f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-5.18f, 4.44f, -5.02f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** TRACKBALL MOUSE - BALL                                     ***/
	/*** The sphere pokes up out of the body top; rolling it is     ***/
	/*** what moves the cursor instead of sliding the whole mouse   ***/
	/******************************************************************/
	// ball radius a bit under half
	// the body width
	// none needed, a sphere is
	// symmetrical
	// centered in the body so
	// the bottom half is sunk into it and the dome sticks out of
	// the top surface
	// mottled red like a
	// classic trackball
	RenderObject(SceneObject(SceneObject::SPHERE,
		glm::vec3(0.3f, 0.3f, 0.3f), ROTATION_NONE,
		glm::vec3(-5.18f, 4.56f, -5.02f), COLOR_TRACKBALL, TEXTURE_BALL, glm::vec2(1.0f, 1.0f),
		MATERIAL_GLOSSY));
	/****************************************************************/

	/******************************************************************/
	/*** TRACKBALL MOUSE - SCROLL RING                              ***/
	/*** The click wheel is a ring that wraps around the ball; the  ***/
	/*** torus mesh is generated upright in the XY plane, so it is  ***/
	/*** tipped 90 degrees about X to lie flat around the ball      ***/
	/******************************************************************/
	// ring radius just larger than
	// the ball's visible dome
	// 90 degrees about X lays
	// the upright ring flat on the body top around the ball
	// centered on the ball at
	// body top height
	// dark plastic
	RenderObject(SceneObject(SceneObject::TORUS,
		glm::vec3(0.26f, 0.26f, 0.26f), glm::vec3(90.0f, 0.0f, 0.0f),
		glm::vec3(-5.18f, 4.53f, -5.02f), COLOR_METAL, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** TRACKBALL MOUSE - FOUR BUTTONS                             ***/
	/*** Four small buttons set into the body top around the ball   ***/
	/******************************************************************/
	// small flat button, sized for
	// a fingertip
	// 45 degrees about Y to
	// match the body
	// front-right of the ball
	// dark plastic
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.16f, 0.05f, 0.32f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-4.79f, 4.545f, -4.97f), COLOR_DARK_GRAY, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	// front-left of the ball
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.16f, 0.05f, 0.32f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-5.13f, 4.545f, -4.62f), COLOR_DARK_GRAY, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	// back-right of the ball
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.16f, 0.05f, 0.32f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-5.23f, 4.545f, -5.42f), COLOR_DARK_GRAY, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	// back-left of the ball
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.16f, 0.05f, 0.32f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-5.57f, 4.545f, -5.07f), COLOR_DARK_GRAY, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** MICROPHONE - DESK BASE                                     ***/
	/*** The boom microphone on the right side of the desk in the   ***/
	/*** reference image; built from a cylinder base and post, a    ***/
	/*** box boom arm, and a tapered cylinder capsule               ***/
	/******************************************************************/
	// flat cylinder base; the
	// cylinder mesh is radius 1 and height 1 with its base at y=0
	// none needed, a cylinder
	// is symmetrical about Y
	// on the desktop surface
	// (y=4.3) to the right of the monitor array
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::CYLINDER,
		glm::vec3(0.28f, 0.08f, 0.28f), ROTATION_NONE,
		glm::vec3(-3.0f, 4.3f, -6.4f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** MICROPHONE - VERTICAL POST                                 ***/
	/******************************************************************/
	// thin tall post rising off
	// the base
	// growing up from the base
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::CYLINDER,
		glm::vec3(0.05f, 0.8f, 0.05f), ROTATION_NONE,
		glm::vec3(-3.0f, 4.38f, -6.4f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** MICROPHONE - BOOM ARM                                      ***/
	/******************************************************************/
	// thin angled arm reaching out
	// over the desk toward the user
	// 35 degrees about X tips
	// the top of the arm forward toward the user
	// hinged at the top of the
	// post and leaning forward over the desk
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(0.08f, 1.1f, 0.08f), glm::vec3(35.0f, 0.0f, 0.0f),
		glm::vec3(-3.0f, 5.63f, -6.08f), COLOR_BLACK, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** MICROPHONE - CAPSULE                                       ***/
	/******************************************************************/
	// the mic body, a little
	// wider than the arm; the tapered cylinder mesh is radius 1
	// at its base and height 1 with its base at y=0
	// upside down so it hangs
	// from the end of the boom arm like a real boom mic
	// hanging just under the
	// end of the boom arm
	// dark plastic
	RenderObject(SceneObject(SceneObject::TAPERED_CYLINDER,
		glm::vec3(0.14f, 0.5f, 0.14f), glm::vec3(180.0f, 0.0f, 0.0f),
		glm::vec3(-3.0f, 6.05f, -5.75f), COLOR_MIC, TEXTURE_GRILLE, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** SOUNDBAR - BODY                                            ***/
	/*** A low horizontal speaker bar laying on the desk directly   ***/
	/*** below the middle monitor, angled with the desk's 45 degree ***/
	/*** corner so its long face points toward the user             ***/
	/******************************************************************/
	// long, short, and shallow
	// like a real soundbar
	// 45 degrees about Y lines
	// the bar up with the middle monitor and the corner wedge
	// on the desktop (y=4.3)
	// just in front of the middle monitor's stand
	// dark plastic grain
	RenderObject(SceneObject(SceneObject::BOX,
		glm::vec3(3.0f, 0.35f, 0.35f), ROTATION_DESK_DIAGONAL,
		glm::vec3(-7.9f, 4.48f, -5.4f), glm::vec4(0.08f, 0.08f, 0.09f, 1), TEXTURE_GRILLE, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** SOUNDBAR - LEFT DRIVER                                     ***/
	/******************************************************************/
	// small flat cylinder driver;
	// the cylinder's Y axis becomes Z after the 90 degree X
	// rotation, so the Y scale sets the driver's thickness
	// 90 about X lays the
	// cylinder axis horizontal, then 45 about Y points the face
	// along the soundbar's front normal toward the user
	// on the front face toward
	// the left end of the bar
	// dark plastic driver
	RenderObject(SceneObject(SceneObject::CYLINDER,
		glm::vec3(0.14f, 0.05f, 0.14f), glm::vec3(90.0f, 45.0f, 0.0f),
		glm::vec3(-8.42f, 4.48f, -4.64f), COLOR_DRIVER, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** SOUNDBAR - CENTER TWEETER                                  ***/
	/******************************************************************/
	// smaller than the drivers
	// same facing as the drivers
	// center of the front face
	// dark plastic driver
	RenderObject(SceneObject(SceneObject::CYLINDER,
		glm::vec3(0.08f, 0.05f, 0.08f), glm::vec3(90.0f, 45.0f, 0.0f),
		glm::vec3(-7.78f, 4.48f, -5.28f), COLOR_DRIVER, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/

	/******************************************************************/
	/*** SOUNDBAR - RIGHT DRIVER                                    ***/
	/******************************************************************/
	// matches the left driver
	// same facing as the drivers
	// on the front face toward
	// the right end of the bar
	// dark plastic driver
	RenderObject(SceneObject(SceneObject::CYLINDER,
		glm::vec3(0.14f, 0.05f, 0.14f), glm::vec3(90.0f, 45.0f, 0.0f),
		glm::vec3(-7.14f, 4.48f, -5.92f), COLOR_DRIVER, TEXTURE_PLASTIC, glm::vec2(1.0f, 1.0f)));
	/****************************************************************/
}
