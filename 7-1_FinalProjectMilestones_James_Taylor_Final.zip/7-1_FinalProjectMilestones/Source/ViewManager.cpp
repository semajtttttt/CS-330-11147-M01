///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;

	// camera state from the last movement message printed to the
	// console; comparing against it each frame lets the log catch
	// movement from any control, and the timestamp throttles the
	// output so a held key does not flood the console
	glm::vec3 gLastLoggedPosition(0.0f);
	float gLastLoggedYaw = 0.0f;
	float gLastLoggedPitch = 0.0f;
	float gLastCameraLogTime = -1.0f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters - positioned slightly left of
	// center, raised up, and pitched down to give a top view of
	// the desk surface and the items sitting on it
	g_pCamera->Position = glm::vec3(-2.0f, 9.0f, 8.5f);
	g_pCamera->Front = glm::vec3(0.0f, -1.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
	// set the yaw and pitch to match the default front vector so the
	// camera orientation stays consistent when the first mouse
	// movement recalculates the front vector from the euler angles
	g_pCamera->Yaw = -90.0f;
	g_pCamera->Pitch = -36.87f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events so the cursor stays hidden
	// and camera look controls work without the cursor leaving the window
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse scroll wheel events
	glfwSetScrollCallback(window, &ViewManager::Mouse_Wheel_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// print the camera controls to the console so the user knows
	// how to move around the scene
	std::cout << "\n=== Camera Controls ===" << std::endl;
	std::cout << "  W / S .......... move forward / backward" << std::endl;
	std::cout << "  A / D .......... move left / right" << std::endl;
	std::cout << "  Q / E .......... move up / down" << std::endl;
	std::cout << "  Mouse .......... look around" << std::endl;
	std::cout << "  Scroll wheel ... adjust movement speed" << std::endl;
	std::cout << "  P .............. perspective (3D) view" << std::endl;
	std::cout << "  O .............. orthographic (2D) view" << std::endl;
	std::cout << "  ESC ............ quit" << std::endl;
	std::cout << std::endl;

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// when the first mouse move event is received, this needs to be recorded so that
	// all subsequent mouse moves can correctly calculate the X position offset and Y
	// position offset for proper operation
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// calculate the X offset and Y offset values for moving the 3D camera accordingly
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // reversed since y-coordinates go from bottom to top

	// set the current positions into the last position variables
	gLastX = xMousePos;
	gLastY = yMousePos;

	// move the 3D camera according to the calculated offsets - this
	// lets the camera look up and down or right and left
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Wheel_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is used within the active GLFW
 *  display window.
 ***********************************************************/
void ViewManager::Mouse_Wheel_Callback(GLFWwindow* window, double xWheelOffset, double yWheelOffset)
{
	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// the vertical scroll offset adjusts the speed that the
	// camera travels around the 3D scene (scroll up = faster,
	// scroll down = slower)
	g_pCamera->ProcessMouseScroll(static_cast<float>(yWheelOffset));

	// log the new camera travel speed to the console
	std::cout << "Camera movement speed: " << g_pCamera->MovementSpeed << std::endl;
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// process camera moving forward and backward (zoom in / zoom out)
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// process camera panning left and right
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// process camera moving upward and downward
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	// the P key switches to perspective (3D) projection and the
	// O key switches to orthographic (2D) projection - each key
	// selects a fixed mode so holding the key does not flicker;
	// the change is only logged when the mode actually switches
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS && bOrthographicProjection)
	{
		bOrthographicProjection = false;
		std::cout << "Projection switched to perspective (3D)" << std::endl;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS && !bOrthographicProjection)
	{
		bOrthographicProjection = true;
		std::cout << "Projection switched to orthographic (2D)" << std::endl;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// log camera movement to the console whenever the position or
	// look direction changed since the last logged message, at
	// most twice a second so held keys and mouse look do not
	// flood the output
	bool cameraChanged =
		(g_pCamera->Position != gLastLoggedPosition) ||
		(g_pCamera->Yaw != gLastLoggedYaw) ||
		(g_pCamera->Pitch != gLastLoggedPitch);
	if (cameraChanged && (currentFrame - gLastCameraLogTime > 0.5f))
	{
		std::cout << "Camera position: (" << g_pCamera->Position.x << ", "
			<< g_pCamera->Position.y << ", " << g_pCamera->Position.z
			<< ")  yaw: " << g_pCamera->Yaw << "  pitch: " << g_pCamera->Pitch << std::endl;
		gLastLoggedPosition = g_pCamera->Position;
		gLastLoggedYaw = g_pCamera->Yaw;
		gLastLoggedPitch = g_pCamera->Pitch;
		gLastCameraLogTime = currentFrame;
	}

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// if orthographic projection is enabled, use a fixed straight-on
	// view of the scene - the eye looks directly at the desk object
	// on a level line, so the floor plane is viewed edge-on and is
	// not visible in the orthographic (2D) display
	if (bOrthographicProjection)
	{
		view = glm::lookAt(
			glm::vec3(-3.0f, 5.5f, 10.0f),	// eye position in front of the scene
			glm::vec3(-3.0f, 5.5f, -7.0f),	// looking straight at the back wall / desk
			glm::vec3(0.0f, 1.0f, 0.0f));	// up vector

		// define the orthographic projection matrix - bounds are
		// scaled to roughly match the window's 1000x800 aspect ratio
		projection = glm::ortho(-10.0f, 10.0f, -8.0f, 8.0f, 0.1f, 100.0f);
	}
	else
	{
		// define the perspective projection matrix using the
		// camera's field of view value
		projection = glm::perspective(glm::radians(g_pCamera->Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}