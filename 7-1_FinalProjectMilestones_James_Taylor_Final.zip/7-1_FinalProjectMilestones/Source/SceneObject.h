///////////////////////////////////////////////////////////////////////////////
// sceneobject.h
// ============
// a single 3D object in the scene: one basic mesh bundled with the
// scale, rotation, translation, and color or texture used to draw it
///////////////////////////////////////////////////////////////////////////////
#pragma once

#include <glm/glm.hpp>

// forward declaration - only a pointer is used in this header
class ShapeMeshes;

class SceneObject
{
public:
	// the basic meshes a scene object can be built from
	enum MESH_TYPE
	{
		BOX,
		PLANE,
		CONE,
		CYLINDER,
		PRISM,
		PYRAMID,
		SPHERE,
		TAPERED_CYLINDER,
		TORUS
	};

	// textureTag names a texture loaded by SceneManager - leave it
	// empty to draw the object with its solid color instead;
	// uvScale tiles the texture across the object's faces;
	// materialTag names a material defined by SceneManager -
	// "matte" is the default finish used when none is given
	SceneObject(MESH_TYPE mesh,
		glm::vec3 scaleXYZ,
		glm::vec3 rotationDegreesXYZ,
		glm::vec3 positionXYZ,
		glm::vec4 colorRGBA,
		const char* textureTag = "",
		glm::vec2 uvScale = glm::vec2(1.0f),
		const char* materialTag = "matte");

	// getters used by SceneManager when rendering the object
	const glm::vec3& Scale() const { return m_scaleXYZ; }
	const glm::vec3& Rotation() const { return m_rotationDegreesXYZ; }
	const glm::vec3& Position() const { return m_positionXYZ; }
	const glm::vec4& Color() const { return m_colorRGBA; }
	const char* TextureTag() const { return m_textureTag; }
	const glm::vec2& UVScale() const { return m_uvScale; }
	const char* MaterialTag() const { return m_materialTag; }
	bool HasTexture() const { return m_textureTag[0] != '\0'; }

	// issue the draw call for this object's mesh
	void DrawMesh(ShapeMeshes* pBasicMeshes) const;

private:
	MESH_TYPE m_mesh;				// which basic mesh to draw
	glm::vec3 m_scaleXYZ;			// size along each axis
	glm::vec3 m_rotationDegreesXYZ;	// rotation in degrees about each axis
	glm::vec3 m_positionXYZ;		// location in the scene
	glm::vec4 m_colorRGBA;			// solid color sent to the shader
	const char* m_textureTag;		// loaded texture tag, "" for color only
	glm::vec2 m_uvScale;			// texture tiling factors along U and V
	const char* m_materialTag;		// defined material tag for lighting
};
