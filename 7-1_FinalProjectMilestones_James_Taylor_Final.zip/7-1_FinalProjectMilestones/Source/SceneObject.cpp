///////////////////////////////////////////////////////////////////////////////
// sceneobject.cpp
// ============
// implementation for the SceneObject class
///////////////////////////////////////////////////////////////////////////////
#include "SceneObject.h"
#include "ShapeMeshes.h"

/***********************************************************
 *  SceneObject()
 *
 *  The constructor stores everything needed to draw one 3D
 *  object: its basic mesh and the scale -> rotate -> translate
 *  transform plus color applied to it.
 ***********************************************************/
SceneObject::SceneObject(MESH_TYPE mesh,
	glm::vec3 scaleXYZ,
	glm::vec3 rotationDegreesXYZ,
	glm::vec3 positionXYZ,
	glm::vec4 colorRGBA,
	const char* textureTag,
	glm::vec2 uvScale,
	const char* materialTag)
{
	m_mesh = mesh;
	m_scaleXYZ = scaleXYZ;
	m_rotationDegreesXYZ = rotationDegreesXYZ;
	m_positionXYZ = positionXYZ;
	m_colorRGBA = colorRGBA;
	m_textureTag = textureTag;
	m_uvScale = uvScale;
	m_materialTag = materialTag;
}

/***********************************************************
 *  DrawMesh()
 *
 *  Looks up this object's mesh type and calls the matching
 *  draw method on the mesh collection.
 ***********************************************************/
void SceneObject::DrawMesh(ShapeMeshes* pBasicMeshes) const
{
	if (NULL == pBasicMeshes)
	{
		return;
	}

	switch (m_mesh)
	{
	case BOX:				pBasicMeshes->DrawBoxMesh(); break;
	case PLANE:				pBasicMeshes->DrawPlaneMesh(); break;
	case CONE:				pBasicMeshes->DrawConeMesh(); break;
	case CYLINDER:			pBasicMeshes->DrawCylinderMesh(); break;
	case PRISM:				pBasicMeshes->DrawPrismMesh(); break;
	case PYRAMID:			pBasicMeshes->DrawPyramid4Mesh(); break;
	case SPHERE:			pBasicMeshes->DrawSphereMesh(); break;
	case TAPERED_CYLINDER:	pBasicMeshes->DrawTaperedCylinderMesh(); break;
	case TORUS:				pBasicMeshes->DrawTorusMesh(); break;
	}
}
